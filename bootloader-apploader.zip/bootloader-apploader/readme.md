# Bluetooth AppLoader OTA DFU

Standalone Bootloader using the Bluetooth AppLoader OTA DFU. This bootloader allows to update application using in-place update where the old application is directly overwritten with the new one.
